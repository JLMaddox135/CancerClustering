from operator import mod
import pandas as pd
import numpy as np
import math

nycancer = pd.read_csv("/Users/7i3/Documents/Python/NYSDOH_CancerMapping_Data_2005_2009.csv")

nycancer_lb = nycancer.loc[:, ["observed_Brain", "expected_Brain", "highlight_Brain", "observed_Lung", "expected_Lung", "highlight_Lung"]]
geoid = nycancer.loc[:,["geoid10"]]

geoid["state"] = geoid["geoid10"].str[:2]
geoid["county"] = geoid["geoid10"].str[2:5]
geoid["tract"] = geoid["geoid10"].str[5:11]
geoid["bg"] = geoid["geoid10"].str[11:]

nyfinal = pd.concat([geoid, nycancer_lb], axis=1)
nyfinal.to_csv("/Users/7i3/Documents/Python/ny_blcancer.csv")