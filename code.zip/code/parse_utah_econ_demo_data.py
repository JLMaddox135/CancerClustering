import os
import pandas as pd
from re import findall # regular expression

df = pd.read_excel('Census_Data_Transpose_Race_Reformatted.xlsx', sheet_name = 'Reformatted_Sheet')
cols = df.columns.to_list()
print(cols)

df = df[df['Census Tract'] != 'United States'] # we don't really care about US data, just these 8 census tracts

tracts = findall('\d*\.\d+', str(df['Census Tract'])) # regex to just get the census tracts without the county , state

df['Census Tract'] = tracts # now replace that in the dataframe
df.replace(',', '', regex = True, inplace = True) # get rid of the commas; 1,000 --> 1000
df = df.apply(pd.to_numeric)

df.drop(['Male_Number', 'Female_Number', 'Labor_Force_Pop_16+', 'Civillian_Labor_Force_Pop_16+', 'Unemployed', 'Agriculture', 'Construction', 'Manufacturing', 'Individuals',
'18_Years_+', '65_Years_+'], axis = 1, inplace = True) # these are all count values that have a corresponding percentage, which is what we're really interested in 
print(df)

# there are a few columns that are counts only without a corresponding percentage. we need to get the percentage by normalizing by the population in that tract
df[['Pop_25+', 'Pop_16+', 'Households', 'White Alone', 'Asian Alone (400-499)', 'Black or African American alone', 'Some other race alone', 'Urban', 'Rural']] = \
    (df[['Pop_25+', 'Pop_16+', 'Households', 'White Alone', 'Asian Alone (400-499)', 'Black or African American alone', 'Some other race alone', 'Urban', 'Rural']].div(df['Total_Pop'], axis = 0)) * 100

print(df.columns.to_list())
print(df)

df['Workers_16+'] = (df['Workers_16+'] / df['Employed']) * 100 # get percentage of the commuters that are 16+ 
df.drop('Employed', axis = 1, inplace = True) # then we can drop this

df.to_csv('/Users/ye5/git-projects/cancer-clustering/data/utah_only.csv', header = True)