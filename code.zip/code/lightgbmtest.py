import lightgbm
import pandas as pd
import numpy as np
import sklearn.model_selection as skms

gbm = lightgbm.LGBMRegressor()

#light gbm training functions
#modeled after MSE but sum constraint may be faulty
def custom_train(y_true, y_pred):
    sum_constraint = ((y_pred.sum(axis = -1)) - (y_true.sum(axis = -1)))
    residual = (y_true - y_pred).astype("float") + sum_constraint
    grad = -2*residual
    hess = -2*np.ones(len)
    return grad, hess

def custom_valid(y_true, y_pred, upper_bound):
    sum_constraint = ((y_pred.sum(axis = -1)) - (y_true.sum(axis = -1)))**2
    residual = ((y_true - y_pred).astype("float"))**2 + sum_constraint
    loss = residual
    return "custom_asymmetric_eval", np.mean(loss), False

#Column/Row Selections
rest = ['Total_Pop','Male_Percent', 'Female_Percent','Pop_25+', 'Percent_HSGrad_Pop_25+', 'Pop_16+','Percent_Labor_Force_Pop_16+', 'Percent_Civillian_Labor_Force_Pop_16+','Percent_Employed', 'Percent_Unemployed', 'Workers_16+',\
    'Mean_Travel_Time', 'Agriculture_Percent', 'Construction_Percent','Manufacturing_Percent', 'Households', 'Median_household_income','Mean_earnings', 'Percent_Below_Poverty_Level','Percent_Below_Poverty_Level_18+', 
    'Percent_Below_Poverty_Level_65+','White_alone', 'Asian_alone', 'Black_or_African_American_alone','American_Indian_and_Alaska_Native_alone','Native_Hawaiian_and_Other_Pacific_Islander_alone','Some_other_race_alone', 'Two_or_more_races',
    'Urban', 'Rural']
matchct = ["Census Tract 141, Kings County, New York", "Census Tract 106, Whatcom County, Washington", "Census Tract 9701, Hickman County, Kentucky", "Census Tract 9702, Fremont County, Idaho", "Census Tract 17.66, Travis County, Texas",\
    "Census Tract 272, Jefferson Parish, Louisiana", "Census Tract 105.01, Ouachita Parish, Louisiana", "Census Tract 94.04, Sacramento County, California", "Census Tract 18.13, Travis County, Texas", "Census Tract 9503, Lampasas County, Texas",
    "Census Tract 108.02, Hays County, Texas", "Census Tract 1469.01, Suffolk County, New York", "Census Tract 607.02, Saratoga County, New York", "Census Tract 1.05, Madera County, California", "Census Tract 202, Bell County, Texas",
    "Census Tract 9602, Idaho County, Idaho", "Census Tract 46, Bremer County, Iowa", "Census Tract 1006, Clinton County, New York", "Census Tract 201.03, San Diego County, California", "Census Tract 9637, La Salle County, Illinois",
    "Census Tract 93.01, Erie County, New York", "Census Tract 442, Riverside County, California", "Census Tract 3672, Contra Costa County, California", "Census Tract 4354, Alameda County, California", "Census Tract 1425, New Haven County, Connecticut",
    "Census Tract 8003.24, Los Angeles County, California", "Census Tract 320.53, Orange County, California", "Census Tract 319.02, Union County, New Jersey", "Census Tract 7329.01, Worcester County, Massachusetts", "Census Tract 29.04, Tulare County, California",
    "Census Tract 1130.01, Tarrant County, Texas", "Census Tract 6719, Fort Bend County, Texas", "Census Tract 19, Dona Ana County, New Mexico", "Census Tract 24, Queens County, New York", "Census Tract 8615.06, Lake County, Illinois",
    "Census Tract 102, Cumberland County, New Jersey", "Census Tract 1304.06, Johnson County, Texas", "Census Tract 1154.01, Los Angeles County, California", "Census Tract 7511, Worcester County, Massachusetts", "Census Tract 217.12, Denton County, Texas"]
states = ["California", "Connecticut", "Idaho", "Illinois", "Iowa", "Kentucky", "Louisiana", "Massachusetts", "New Jersey", "New Mexico", "New York", "Texas", "Washington"]
utah_exposed = ["Census Tract 1251.03, Davis County, Utah", "Census Tract 1251.04, Davis County, Utah", "Census Tract 1258.04, Davis County, Utah", "Census Tract 1258.05, Davis County, Utah", "Census Tract 1258.06, Davis County, Utah", "Census Tract 1259.04, Davis County, Utah", "Census Tract 1259.05, Davis County, Utah", "Census Tract 1259.06, Davis County, Utah"]

#Matched CTs for each Exposed Census Tract. (I can provide Mahalanobis distance if need be)
matchct12513 = ["Census Tract 141, Kings County, New York", "Census Tract 106, Whatcom County, Washington", "Census Tract 9701, Hickman County, Kentucky", "Census Tract 9702, Fremont County, Idaho", "Census Tract 17.66, Travis County, Texas"]
matchct12514 = ["Census Tract 272, Jefferson Parish, Louisiana", "Census Tract 105.01, Ouachita Parish, Louisiana", "Census Tract 94.04, Sacramento County, California", "Census Tract 18.13, Travis County, Texas", "Census Tract 9503, Lampasas County, Texas"]
matchct12584 = ["Census Tract 108.02, Hays County, Texas", "Census Tract 1469.01, Suffolk County, New York", "Census Tract 607.02, Saratoga County, New York", "Census Tract 1.05, Madera County, California", "Census Tract 202, Bell County, Texas"]
matchct12585 = ["Census Tract 9602, Idaho County, Idaho", "Census Tract 46, Bremer County, Iowa", "Census Tract 1006, Clinton County, New York", "Census Tract 201.03, San Diego County, California", "Census Tract 9637, La Salle County, Illinois"]
matchct12586 = ["Census Tract 93.01, Erie County, New York", "Census Tract 442, Riverside County, California", "Census Tract 3672, Contra Costa County, California", "Census Tract 4354, Alameda County, California", "Census Tract 1425, New Haven County, Connecticut"]
matchct12594 = ["Census Tract 8003.24, Los Angeles County, California", "Census Tract 320.53, Orange County, California", "Census Tract 319.02, Union County, New Jersey", "Census Tract 7329.01, Worcester County, Massachusetts", "Census Tract 29.04, Tulare County, California"]
matchct12595 = ["Census Tract 1130.01, Tarrant County, Texas", "Census Tract 6719, Fort Bend County, Texas", "Census Tract 19, Dona Ana County, New Mexico", "Census Tract 24, Queens County, New York", "Census Tract 8615.06, Lake County, Illinois"]
matchct12596 = ["Census Tract 102, Cumberland County, New Jersey", "Census Tract 1304.06, Johnson County, Texas", "Census Tract 1154.01, Los Angeles County, California", "Census Tract 7511, Worcester County, Massachusetts", "Census Tract 217.12, Denton County, Texas"]

#setting custom function
gbm.set_params(**{'objective': custom_train}, metrics = ["mse", 'mae'])

#Reading and formatting allus
allus = pd.read_csv("allus.csv", dtype={'id': str})
allus = allus.drop("Unnamed: 0", axis =1)
allus = allus.dropna(axis = 0, subset = rest)
county_state = allus["Census_Tract"].str.extract(', (\w+ \w+ \w+|\w+ \w+), (\w+ \w+|\w+)')
allus["county"] = county_state[0]
allus["state"] = county_state[1]
allus = allus[["Census_Tract", "id", "county", "state", 'Total_Pop','Male_Percent', 'Female_Percent','Pop_25+', 'Percent_HSGrad_Pop_25+', 'Pop_16+','Percent_Labor_Force_Pop_16+', 'Percent_Civillian_Labor_Force_Pop_16+','Percent_Employed', 'Percent_Unemployed', 'Workers_16+',\
    'Mean_Travel_Time', 'Agriculture_Percent', 'Construction_Percent','Manufacturing_Percent', 'Households', 'Median_household_income','Mean_earnings', 'Percent_Below_Poverty_Level','Percent_Below_Poverty_Level_18+', 
    'Percent_Below_Poverty_Level_65+','White_alone', 'Asian_alone', 'Black_or_African_American_alone','American_Indian_and_Alaska_Native_alone','Native_Hawaiian_and_Other_Pacific_Islander_alone','Some_other_race_alone', 'Two_or_more_races',
    'Urban', 'Rural', "observed_Brain", "observed_Lung"]]

#New York Data
ny = allus.dropna(axis = 0, subset=['observed_Brain', 'observed_Lung'])

#Subsetting to just Utah counties
temput = allus[allus["state"] == "Utah"]

#SEER UPPER BOUND(2000-2004)
#utahct = temput[temput["county"] == "Davis County"]
#utahct["Brain_SEER"] = 76
#utahct["Lung_SEER"] = 240

#LAYTON UPPER BOUND (1999-2003)
utahct = temput[temput["Census_Tract"].isin(utah_exposed)]
utahct["Brain_SEER"] = 17
utahct["Lung_SEER"] = 46

### SEER DATA FORMATTING
#reading and summing across 2000-2004
lungseer = pd.read_csv("lbseerfinal.csv", dtype={'lbseer.County': str})
lungseer["sum"] = lungseer["lbseer.X2000"] + lungseer["lbseer.X2001"] + lungseer["lbseer.X2002"] + lungseer["lbseer.X2003"] + lungseer["lbseer.X2004"]
brainseer = pd.read_csv("brainseerfinal.csv", dtype={'brainseer.County': str})
brainseer["sum"] = brainseer["brainseer.X2000"] + brainseer["brainseer.X2001"] + brainseer["brainseer.X2002"] + brainseer["brainseer.X2003"] + brainseer["brainseer.X2004"]

#extracting state and counties
lungseer["State"] = lungseer["lbseer.County"].str.extract('(\w+):')
lungseer["County"] = lungseer["lbseer.County"].str.extract(': (\w+ \w+ \w+|\w+ \w+)')
brainseer["State"] = brainseer["brainseer.County"].str.extract('(\w+):')
brainseer["County"] = brainseer["brainseer.County"].str.extract(': (\w+ \w+ \w+|\w+ \w+)')

#Reducing SEER data to what is necessary and fixing Los Angeles Registry
lungseerred = lungseer[["County", "sum"]]
lungseerred.columns = ["County", "Lung_SEER"]
lungseerred["County"] = lungseerred["County"].str.replace(pat='Registry', repl="County")
brainseerred = brainseer[["County", "sum"]]
brainseerred.columns = ["County", "Brain_SEER"]
brainseerred["County"] = brainseerred["County"].str.replace(pat='Registry', repl="County")

#Combining SEER data through a merge on Counties
seertot = pd.merge(left = brainseerred, right = lungseerred, on="County")

#Selecting only counties with matched census tracts in them 
# (Selection already done when making the csvs for lungseer and brainseer so just matching by counties with SEER data)
temp = allus[allus["county"].isin(lungseerred["County"])]

#Removing counties with names that are the same bby selecting only states we want
temp2 = temp[temp["state"].isin(states)]

#Forming the final dataset with geographical information, covariates, cancer incidence and SEER upper 
#limits for each county containing a matched census tract
seer_ct = pd.merge(left = temp2, right = seertot, left_on="county", right_on="County")
seer_ct = seer_ct.drop("County", axis = 1)


#################  BRAIN prediction   ######################
X = ny[rest]
y = ny[['observed_Brain']]

X_train, X_test, y_train, y_test = skms.train_test_split(X, y, test_size=0.2, train_size=0.8)

# fitting model 
gbm.fit(X_train,y_train,eval_set=[(X_test, y_test["observed_Brain"]),],eval_metric=custom_valid, verbose=False,)
seer_ct['predicted_Brain'] = gbm.predict(seer_ct[rest])
utahct['predicted_Brain'] = gbm.predict(utahct[rest])

#################  LUNG prediction    ######################
X = ny[rest]
y = ny[['observed_Lung']]

X_train, X_test, y_train, y_test = skms.train_test_split(X, y, test_size=0.2, train_size=0.8)

# fitting model 
gbm.fit(X_train,y_train,eval_set=[(X_test, y_test)],eval_metric=custom_valid, verbose=False,)
seer_ct['predicted_Lung'] = gbm.predict(seer_ct[rest])
utahct['predicted_Lung'] = gbm.predict(utahct[rest])

utahct_final = utahct[["Census_Tract", "county", "Lung_SEER", "predicted_Lung", "Brain_SEER", "predicted_Brain"]]

#Exposed ct incidence rates
exposedct = utahct_final[utahct_final["Census_Tract"].isin(utah_exposed)]

#Subsetting for each 5 matched census tracts
seer_ct_12513 = seer_ct[seer_ct["Census_Tract"].isin(matchct12513)]
seer_ct_12514 = seer_ct[seer_ct["Census_Tract"].isin(matchct12514)]
seer_ct_12584 = seer_ct[seer_ct["Census_Tract"].isin(matchct12584)]
seer_ct_12585 = seer_ct[seer_ct["Census_Tract"].isin(matchct12585)]
seer_ct_12586 = seer_ct[seer_ct["Census_Tract"].isin(matchct12586)]
seer_ct_12594 = seer_ct[seer_ct["Census_Tract"].isin(matchct12594)]
seer_ct_12595 = seer_ct[seer_ct["Census_Tract"].isin(matchct12595)]
seer_ct_12596 = seer_ct[seer_ct["Census_Tract"].isin(matchct12596)]

csirdf = pd.DataFrame(utah_exposed, columns=["census_tract"])

#Averaging lung cancer frequency in the 5 matched census tracts
lungnonex12513 = seer_ct_12513["predicted_Lung"].sum()/5
lungnonex12514 = seer_ct_12514["predicted_Lung"].sum()/5
lungnonex12584 = seer_ct_12584["predicted_Lung"].sum()/5
lungnonex12585 = seer_ct_12585["predicted_Lung"].sum()/5
lungnonex12586 = seer_ct_12586["predicted_Lung"].sum()/5
lungnonex12594 = seer_ct_12594["predicted_Lung"].sum()/5
lungnonex12595 = seer_ct_12595["predicted_Lung"].sum()/5
lungnonex12596 = seer_ct_12596["predicted_Lung"].sum()/5

csirdf["lungnonexposed"] = [lungnonex12513, lungnonex12514, lungnonex12584, lungnonex12585, lungnonex12586, lungnonex12594, lungnonex12595, lungnonex12596]

#Averaging brain cancer frequency in the 5 matched census tracts
brainnonex12513 = seer_ct_12513["predicted_Brain"].sum()/5
brainnonex12514 = seer_ct_12514["predicted_Brain"].sum()/5
brainnonex12584 = seer_ct_12584["predicted_Brain"].sum()/5
brainnonex12585 = seer_ct_12585["predicted_Brain"].sum()/5
brainnonex12586 = seer_ct_12586["predicted_Brain"].sum()/5
brainnonex12594 = seer_ct_12594["predicted_Brain"].sum()/5
brainnonex12595 = seer_ct_12595["predicted_Brain"].sum()/5
brainnonex12596 = seer_ct_12596["predicted_Brain"].sum()/5

csirdf["brainnonexposed"]= [brainnonex12513, brainnonex12514, brainnonex12584, brainnonex12585, brainnonex12586, brainnonex12594, brainnonex12595, brainnonex12596]

#Compiling exposed cancer frequencies into csirdf
csirdf["brainexposed"] = exposedct["predicted_Brain"].values
csirdf["lungexposed"] = exposedct["predicted_Lung"].values

#Calculating cSIR scores
csirdf["Lung_cSIR"] = csirdf["lungexposed"]/ csirdf["lungnonexposed"]
csirdf["Brain_cSIR"] = csirdf["brainexposed"] / csirdf["brainnonexposed"]
print(csirdf["Brain_cSIR"])
print(csirdf["Lung_cSIR"])