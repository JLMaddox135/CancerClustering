import pandas as pd
import numpy as np
import scipy as sp
import sklearn.ensemble as ske
import sklearn.model_selection as skms

us_state_to_abbrev = {
    "Alabama": "AL",
    "Alaska": "AK",
    "Arizona": "AZ",
    "Arkansas": "AR",
    "California": "CA",
    "Colorado": "CO",
    "Connecticut": "CT",
    "Delaware": "DE",
    "Florida": "FL",
    "Georgia": "GA",
    "Hawaii": "HI",
    "Idaho": "ID",
    "Illinois": "IL",
    "Indiana": "IN",
    "Iowa": "IA",
    "Kansas": "KS",
    "Kentucky": "KY",
    "Louisiana": "LA",
    "Maine": "ME",
    "Maryland": "MD",
    "Massachusetts": "MA",
    "Michigan": "MI",
    "Minnesota": "MN",
    "Mississippi": "MS",
    "Missouri": "MO",
    "Montana": "MT",
    "Nebraska": "NE",
    "Nevada": "NV",
    "New Hampshire": "NH",
    "New Jersey": "NJ",
    "New Mexico": "NM",
    "New York": "NY",
    "North Carolina": "NC",
    "North Dakota": "ND",
    "Ohio": "OH",
    "Oklahoma": "OK",
    "Oregon": "OR",
    "Pennsylvania": "PA",
    "Rhode Island": "RI",
    "South Carolina": "SC",
    "South Dakota": "SD",
    "Tennessee": "TN",
    "Texas": "TX",
    "Utah": "UT",
    "Vermont": "VT",
    "Virginia": "VA",
    "Washington": "WA",
    "West Virginia": "WV",
    "Wisconsin": "WI",
    "Wyoming": "WY",
    "District of Columbia": "DC",
    "American Samoa": "AS",
    "Guam": "GU",
    "Northern Mariana Islands": "MP",
    "Puerto Rico": "PR",
    "United States Minor Outlying Islands": "UM",
    "U.S. Virgin Islands": "VI",
}

abbrev_to_us_state = dict(map(reversed, us_state_to_abbrev.items()))

def conditionlung(s):
    if (s['predicted_Lung'] >= s["lowlimLung"]) and (s["predicted_Lung"] <= s["uplimLung"]):
        return 1
    else:
        return 0

def conditionbrain(s):
    if (s['predicted_Brain'] >= s["lowlimBrain"]) and (s["predicted_Brain"] <= s["uplimBrain"]):
        return 1
    else:
        return 0

rest = ['Total_Pop','Male_Percent', 'Female_Percent','Pop_25+', 'Percent_HSGrad_Pop_25+', 'Pop_16+','Percent_Labor_Force_Pop_16+', 'Percent_Civillian_Labor_Force_Pop_16+','Percent_Employed', 'Percent_Unemployed', 'Workers_16+',\
    'Mean_Travel_Time', 'Agriculture_Percent', 'Construction_Percent','Manufacturing_Percent', 'Households', 'Median_household_income','Mean_earnings', 'Percent_Below_Poverty_Level','Percent_Below_Poverty_Level_18+', 
    'Percent_Below_Poverty_Level_65+','White_alone', 'Asian_alone', 'Black_or_African_American_alone','American_Indian_and_Alaska_Native_alone','Native_Hawaiian_and_Other_Pacific_Islander_alone','Some_other_race_alone', 'Two_or_more_races',
    'Urban', 'Rural']

matchct = ["Census Tract 141, Kings County, New York", "Census Tract 106, Whatcom County, Washington", "Census Tract 9701, Hickman County, Kentucky", "Census Tract 9702, Fremont County, Idaho", "Census Tract 17.66, Travis County, Texas",\
    "Census Tract 272, Jefferson Parish, Louisiana", "Census Tract 105.01, Ouachita Parish, Louisiana", "Census Tract 94.04, Sacramento County, California", "Census Tract 18.13, Travis County, Texas", "Census Tract 9503, Lampasas County, Texas",
    "Census Tract 108.02, Hays County, Texas", "Census Tract 1469.01, Suffolk County, New York", "Census Tract 607.02, Saratoga County, New York", "Census Tract 1.05, Madera County, California", "Census Tract 202, Bell County, Texas",
    "Census Tract 9602, Idaho County, Idaho", "Census Tract 46, Bremer County, Iowa", "Census Tract 1006, Clinton County, New York", "Census Tract 201.03, San Diego County, California", "Census Tract 9637, La Salle County, Illinois",
    "Census Tract 93.01, Erie County, New York", "Census Tract 442, Riverside County, California", "Census Tract 3672, Contra Costa County, California", "Census Tract 4354, Alameda County, California", "Census Tract 1425, New Haven County, Connecticut",
    "Census Tract 8003.24, Los Angeles County, California", "Census Tract 320.53, Orange County, California", "Census Tract 319.02, Union County, New Jersey", "Census Tract 7329.01, Worcester County, Massachusetts", "Census Tract 29.04, Tulare County, California",
    "Census Tract 1130.01, Tarrant County, Texas", "Census Tract 6719, Fort Bend County, Texas", "Census Tract 19, Dona Ana County, New Mexico", "Census Tract 24, Queens County, New York", "Census Tract 8615.06, Lake County, Illinois",
    "Census Tract 102, Cumberland County, New Jersey", "Census Tract 1304.06, Johnson County, Texas", "Census Tract 1154.01, Los Angeles County, California", "Census Tract 7511, Worcester County, Massachusetts", "Census Tract 217.12, Denton County, Texas"]

matchct12513 = pd.read_csv("mat13.csv").drop("Unnamed: 0", axis =1)["Census_Tract"].values.tolist()
matchct12514 = pd.read_csv("mat14.csv").drop("Unnamed: 0", axis =1)["Census_Tract"].values.tolist()
matchct12584 = pd.read_csv("mat84.csv").drop("Unnamed: 0", axis =1)["Census_Tract"].values.tolist()
matchct12585 = pd.read_csv("mat85.csv").drop("Unnamed: 0", axis =1)["Census_Tract"].values.tolist()
matchct12586 = pd.read_csv("mat86.csv").drop("Unnamed: 0", axis =1)["Census_Tract"].values.tolist()
matchct12594 = pd.read_csv("mat94.csv").drop("Unnamed: 0", axis =1)["Census_Tract"].values.tolist()
matchct12595 = pd.read_csv("mat95.csv").drop("Unnamed: 0", axis =1)["Census_Tract"].values.tolist()
matchct12596 = pd.read_csv("mat96.csv").drop("Unnamed: 0", axis =1)["Census_Tract"].values.tolist()
matchct = pd.read_csv("mattot.csv").drop("Unnamed: 0", axis =1)["Census_Tract"].values.tolist()

'''lungseer = pd.read_csv("lbseerfinal.csv", dtype={'lbseer.County': str})
lungseer["sum"] = lungseer["lbseer.X2000"] + lungseer["lbseer.X2001"] + lungseer["lbseer.X2002"] + lungseer["lbseer.X2003"] + lungseer["lbseer.X2004"]
brainseer = pd.read_csv("brainseerfinal.csv", dtype={'brainseer.County': str})
brainseer["sum"] = brainseer["brainseer.X2000"] + brainseer["brainseer.X2001"] + brainseer["brainseer.X2002"] + brainseer["brainseer.X2003"] + brainseer["brainseer.X2004"]
lungseer["State"] = lungseer["lbseer.County"].str.extract('(\w+):')
lungseer["County"] = lungseer["lbseer.County"].str.extract(': (\w+ \w+ \w+|\w+ \w+)')
brainseer["State"] = brainseer["brainseer.County"].str.extract('(\w+):')
brainseer["County"] = brainseer["brainseer.County"].str.extract(': (\w+ \w+ \w+|\w+ \w+)')'''

lungseer = pd.read_csv("lbseerfinal2.csv", dtype={'County': str})
brainseer = pd.read_csv("brainseerfinal2.csv", dtype={'County': str})
lungseer["County"] = lungseer["County"].replace('_', ' ', regex=True)
brainseer["County"] = brainseer["County"].replace('_', ' ', regex=True)
lungseer["State"] = lungseer["County"].str.extract('(\w+):')
lungseer["County"] = lungseer["County"].str.extract(': (\w+ \w+ \w+ \w+ \w+|\w+ \w+ \w+ \w+|\w+ \w+ \w+|\w+ \w+)')
brainseer["State"] = brainseer["County"].str.extract('(\w+):')
brainseer["County"] = brainseer["County"].str.extract(': (\w+ \w+ \w+ \w+ \w+|\w+ \w+ \w+ \w+|\w+ \w+ \w+|\w+ \w+)')
lungseer = lungseer.dropna(axis=0)
brainseer = brainseer.dropna(axis=0)

lungseerred = lungseer[["State", "County", "sum"]]
lungseerred.columns = ["State", "County", "Lung_SEER"]
lungseerred["County"] = lungseerred["County"].str.replace(pat='Registry', repl="County")
brainseerred = brainseer[["State", "County", "sum"]]
brainseerred.columns = ["State", "County", "Brain_SEER"]
brainseerred["County"] = brainseerred["County"].str.replace(pat='Registry', repl="County")
seertot = pd.merge(left = brainseerred, right = lungseerred, on=["State", "County"])
seertot = seertot.replace({"State": abbrev_to_us_state})
seertot["state_county"] = seertot["State"] + " - " + seertot["County"]

states = ["California", "Connecticut", "Idaho", "Illinois", "Iowa", "Kentucky", "Louisiana", "Massachusetts", "New Jersey", "New Mexico", "New York", "Texas", "Washington"]


for loopvar in range(100):
    print(loopvar)
    allus = pd.read_csv("allus.csv", dtype={'id': str})
    allus = allus.drop("Unnamed: 0", axis =1)
    allus = allus.dropna(axis = 0, subset = rest)
    test1 = allus["Census_Tract"].str.extract(', (\w+ \w+ \w+|\w+ \w+), (\w+ \w+|\w+)')
    allus["county"] = test1[0]
    allus["state"] = test1[1]
    ny = allus.dropna(axis = 0, subset=['observed_Brain', 'expected_Brain', 'highlight_Brain', 'observed_Lung', 'expected_Lung', 'highlight_Lung'])
    utah = ["Census Tract 1251.03, Davis County, Utah", "Census Tract 1251.04, Davis County, Utah", "Census Tract 1258.04, Davis County, Utah", "Census Tract 1258.05, Davis County, Utah", "Census Tract 1258.06, Davis County, Utah", "Census Tract 1259.04, Davis County, Utah", "Census Tract 1259.05, Davis County, Utah", "Census Tract 1259.06, Davis County, Utah"]

    temput = allus[allus["state"] == "Utah"]
    utahct = temput[temput["county"] == "Davis County"]
    utahct["Brain_SEER"] = 76
    utahct["Lung_SEER"] = 240
    #utahct = temput[temput["Census_Tract"].isin(utah)]
    #utahct["Brain_SEER"] = 22
    #utahct["Lung_SEER"] = 46

    temp = allus[allus["county"].isin(lungseerred["County"])]
    temp["state_county"] = temp["state"] + " - " + temp["county"]
    #temp2 = temp[temp["state"].isin(states)]
    #seer_ct = pd.merge(left = temp2, right = seertot, left_on="county", right_on="County")
    seer_ct = pd.merge(left = temp, right = seertot, on="state_county")
    
    ####### BRAIN #######
    sumscore = 0
    while (sumscore < 0.25):
        X = ny[rest]
        y = ny[['observed_Brain']]

        X_train, X_test, y_train, y_test = skms.train_test_split(X, y, test_size=0.2, train_size=0.8)
        reg = ske.GradientBoostingRegressor()
        est = reg.fit(X_train, y_train.values.ravel())
        sumscore = reg.score(X_test, y_test)
        seer_ct['predicted_Brain'] = est.predict(seer_ct[rest])
        utahct['predicted_Brain'] = est.predict(utahct[rest])
        print(sumscore)

    ###### LUNG #######
    sumscore = 0
    while(sumscore < 0.65):
        X = ny[rest]
        y = ny[['observed_Lung']]

        X_train, X_test, y_train, y_test = skms.train_test_split(X, y, test_size=0.2, train_size=0.8)
        reg2 = ske.HistGradientBoostingRegressor()
        est2 = reg2.fit(X_train, y_train.values.ravel())

        sumscore = reg2.score(X_test, y_test)
        seer_ct['predicted_Lung'] = est2.predict(seer_ct[rest])
        utahct['predicted_Lung'] = est2.predict(utahct[rest])
        print(sumscore)

    #bound = 0.25

    sumcounty = seer_ct[["state_county", "State", "County", "predicted_Brain", "predicted_Lung"]].groupby("state_county").sum()
    sumcounty = sumcounty.reset_index()
    sumcounty = pd.merge(left = sumcounty, right=seertot, on="state_county")
    #sumcounty["lowlimBrain"] = sumcounty["Brain_SEER"] - bound*sumcounty["Brain_SEER"]
    #sumcounty["uplimBrain"] = sumcounty["Brain_SEER"] + bound*sumcounty["Brain_SEER"]
    #sumcounty["lowlimLung"] = sumcounty["Lung_SEER"] - bound*sumcounty["Lung_SEER"]
    #sumcounty["uplimLung"] = sumcounty["Lung_SEER"] + bound*sumcounty["Lung_SEER"]
    sumcounty["braincorrection"] = sumcounty["Brain_SEER"]/sumcounty["predicted_Brain"]
    sumcounty["lungcorrection"] = sumcounty["Lung_SEER"]/sumcounty["predicted_Lung"]

    correction_ct = sumcounty[["state_county", "braincorrection", "lungcorrection"]]
    seer_ct = pd.merge(seer_ct, correction_ct, on="state_county")
    seer_ct["brain_corrected"] = seer_ct["predicted_Brain"]*seer_ct["braincorrection"]
    seer_ct["lung_corrected"] = seer_ct["predicted_Lung"]*seer_ct["lungcorrection"]

    sumutahct = utahct[["county", "predicted_Brain", "predicted_Lung"]].groupby("county").sum()
    sumutahct["Lung_SEER"] = 240
    sumutahct["Brain_SEER"] = 76
    sumutahct["braincorrection"] = sumutahct["Brain_SEER"]/sumutahct["predicted_Brain"]
    sumutahct["lungcorrection"] = sumutahct["Lung_SEER"]/sumutahct["predicted_Lung"]
    utahct["braincorrected"] = utahct["predicted_Brain"]*sumutahct["braincorrection"].values
    utahct["lungcorrected"] = utahct["predicted_Lung"]*sumutahct["lungcorrection"].values


    exposedct = utahct[utahct["Census_Tract"].isin(utah)]
    matchnum = 10

    seer_ct_12513 = seer_ct[seer_ct["Census_Tract"].isin(matchct12513)]
    seer_ct_12514 = seer_ct[seer_ct["Census_Tract"].isin(matchct12514)]
    seer_ct_12584 = seer_ct[seer_ct["Census_Tract"].isin(matchct12584)]
    seer_ct_12585 = seer_ct[seer_ct["Census_Tract"].isin(matchct12585)]
    seer_ct_12586 = seer_ct[seer_ct["Census_Tract"].isin(matchct12586)]
    seer_ct_12594 = seer_ct[seer_ct["Census_Tract"].isin(matchct12594)]
    seer_ct_12595 = seer_ct[seer_ct["Census_Tract"].isin(matchct12595)]
    seer_ct_12596 = seer_ct[seer_ct["Census_Tract"].isin(matchct12596)]

    lungnonex12513 = seer_ct_12513["lung_corrected"].sum()/matchnum
    lungnonex12514 = seer_ct_12514["lung_corrected"].sum()/matchnum
    lungnonex12584 = seer_ct_12584["lung_corrected"].sum()/matchnum
    lungnonex12585 = seer_ct_12585["lung_corrected"].sum()/matchnum
    lungnonex12586 = seer_ct_12586["lung_corrected"].sum()/matchnum
    lungnonex12594 = seer_ct_12594["lung_corrected"].sum()/matchnum
    lungnonex12595 = seer_ct_12595["lung_corrected"].sum()/matchnum
    lungnonex12596 = seer_ct_12596["lung_corrected"].sum()/matchnum

    seerdf = pd.DataFrame(utah, columns=["census_tract"])
    seerdf["lungnonexposed"] = [lungnonex12513, lungnonex12514, lungnonex12584, lungnonex12585, lungnonex12586, lungnonex12594, lungnonex12595, lungnonex12596]

    brainnonex12513 = seer_ct_12513["brain_corrected"].sum()/matchnum
    brainnonex12514 = seer_ct_12514["brain_corrected"].sum()/matchnum
    brainnonex12584 = seer_ct_12584["brain_corrected"].sum()/matchnum
    brainnonex12585 = seer_ct_12585["brain_corrected"].sum()/matchnum
    brainnonex12586 = seer_ct_12586["brain_corrected"].sum()/matchnum
    brainnonex12594 = seer_ct_12594["brain_corrected"].sum()/matchnum
    brainnonex12595 = seer_ct_12595["brain_corrected"].sum()/matchnum
    brainnonex12596 = seer_ct_12596["brain_corrected"].sum()/matchnum

    seerdf["brainnonexposed"]= [brainnonex12513, brainnonex12514, brainnonex12584, brainnonex12585, brainnonex12586, brainnonex12594, brainnonex12595, brainnonex12596]
    seerdf["brainexposed"] = exposedct["braincorrected"].values
    seerdf["lungexposed"] = exposedct["lungcorrected"].values
    seerdf["Lung_cSIR"] = seerdf["lungexposed"]/ seerdf["lungnonexposed"]
    seerdf["Brain_cSIR"] = seerdf["brainexposed"] / seerdf["brainnonexposed"]
    if loopvar == 0:
        csirdf = seerdf[["Lung_cSIR", "Brain_cSIR"]]
    
    else:
        csirdf["Lung_cSIR"] = csirdf["Lung_cSIR"] + seerdf["Lung_cSIR"]
        csirdf["Brain_cSIR"] = csirdf["Brain_cSIR"] + seerdf["Brain_cSIR"]

csirdf["Lung_cSIR"] = csirdf["Lung_cSIR"]/100
csirdf["Brain_cSIR"] = csirdf["Brain_cSIR"]/100
csirdf["Census_Tract"] = seerdf["census_tract"]
csirdf = csirdf[["Census_Tract", "Lung_cSIR", "Brain_cSIR"]]

'''
sumcountyu = utahct[["Census_Tract", "county", "Lung_SEER", "Brain_SEER", "predicted_Brain", "predicted_Lung"]]
sumutahct["lowlimBrain"] = sumutahct["Brain_SEER"] - bound*sumutahct["Brain_SEER"]
sumutahct["uplimBrain"] = sumutahct["Brain_SEER"] + bound*sumutahct["Brain_SEER"]
sumutahct["lowlimLung"] = sumutahct["Lung_SEER"] - bound*sumutahct["Lung_SEER"]
sumutahct["uplimLung"] = sumutahct["Lung_SEER"] + bound*sumutahct["Lung_SEER"]

while(sumcountyu["predicted_Lung"].sum() > sumutahct["uplimLung"].values):
    randcounty = sumcountyu.sample(n=1, replace=True).index
    while sumcountyu.loc[randcounty, "predicted_Lung"].values <= 1:
        randcounty = sumcountyu.sample(n=1, replace=True).index
    sumcountyu.loc[randcounty, "predicted_Lung"]-=1

while(sumcountyu["predicted_Brain"].sum() > sumutahct["uplimBrain"].values):
    randcounty = sumcountyu.sample(n=1, replace=True).index
    while sumcountyu.loc[randcounty, "predicted_Lung"].values <= 1:
        randcounty = sumcountyu.sample(n=1, replace=True).index
    sumcountyu.loc[randcounty, "predicted_Brain"]-=1
'''

'''sumcounty2 = seer_ct[["County", "brain_corrected", "lung_corrected"]].groupby("County").sum()
sumcounty2 = pd.merge(left = sumcounty2, right=brainseerred, on="County")
sumcounty2 = pd.merge(left = sumcounty2, right=lungseerred, on="County")

#sumcounty['lungreview'] = sumcounty.apply(conditionlung, axis=1)
#sumcounty['brainreview'] = sumcounty.apply(conditionbrain, axis=1)
#sumcounty['braindiff'] = (sumcounty["predicted_Brain"] - sumcounty["Brain_SEER"]).abs()
#sumcounty["lungdiff"] = (sumcounty["predicted_Lung"] - sumcounty["Lung_SEER"]).abs()
#sumcounty["lungdiff"].sum()
#sumcounty["braindiff"].sum()

for i in sumcounty["County"]:
    print(i)
    loop = sumcounty[sumcounty["County"] == i]
    #print(loop.values)
    countyselect = seer_ct[seer_ct["County"] == i]
    if loop["lungreview"].values == 0:
        if(loop["predicted_Lung"].values < loop["lowlimLung"].values):
            while(countyselect["predicted_Lung"].sum() < loop["lowlimLung"].values):
                randcounty = countyselect.sample(n=1, replace=True).index
                countyselect.loc[randcounty, "predicted_Lung"]+=1
        elif(loop["predicted_Lung"].values > loop["uplimLung"].values):
            while(countyselect["predicted_Lung"].sum() > loop["uplimLung"].values):
                randcounty = countyselect.sample(n=1, replace=True).index
                while countyselect.loc[randcounty, "predicted_Lung"].values <= 1:
                    randcounty = countyselect.sample(n=1, replace=True).index
                countyselect.loc[randcounty, "predicted_Lung"]-=1

    if loop["brainreview"].values == 0:
        if(loop["predicted_Brain"].values < loop["lowlimBrain"].values):
            while(countyselect["predicted_Brain"].sum() < loop["lowlimBrain"].values):
                randcounty = countyselect.sample(n=1, replace=True).index
                countyselect.loc[randcounty, "predicted_Brain"]+=1
        elif(loop["predicted_Brain"].values > loop["uplimBrain"].values):
            while(countyselect["predicted_Brain"].sum() > loop["uplimBrain"].values):
                randcounty = countyselect.sample(n=1, replace=True).index
                while countyselect.loc[randcounty, "predicted_Brain"].values <= 1:
                    randcounty = countyselect.sample(n=1, replace=True).index
                countyselect.loc[randcounty, "predicted_Brain"]-=1
    seer_ct.update(countyselect)


sumcounty2 = seer_ct[["County", "predicted_Brain", "predicted_Lung"]].groupby("County").sum()
sumcounty2 = pd.merge(left = sumcounty2, right=brainseerred, on="County")
sumcounty2["lowlimBrain"] = sumcounty2["Brain_SEER"] - bound*sumcounty2["Brain_SEER"]
sumcounty2["uplimBrain"] = sumcounty2["Brain_SEER"] + bound*sumcounty2["Brain_SEER"]
sumcounty2 = pd.merge(left = sumcounty2, right=lungseerred, on="County")
sumcounty2["lowlimLung"] = sumcounty2["Lung_SEER"] - bound*sumcounty2["Lung_SEER"]
sumcounty2["uplimLung"] = sumcounty2["Lung_SEER"] + bound*sumcounty2["Lung_SEER"]
sumcounty2['lungreview'] = sumcounty2.apply(conditionlung, axis=1)
sumcounty2['brainreview'] = sumcounty2.apply(conditionbrain, axis=1)
'''

'''
seer_ct_12513 = seer_ct[seer_ct["Census_Tract"].isin(matchct12513)]
seer_ct_12514 = seer_ct[seer_ct["Census_Tract"].isin(matchct12514)]
seer_ct_12584 = seer_ct[seer_ct["Census_Tract"].isin(matchct12584)]
seer_ct_12585 = seer_ct[seer_ct["Census_Tract"].isin(matchct12585)]
seer_ct_12586 = seer_ct[seer_ct["Census_Tract"].isin(matchct12586)]
seer_ct_12594 = seer_ct[seer_ct["Census_Tract"].isin(matchct12594)]
seer_ct_12595 = seer_ct[seer_ct["Census_Tract"].isin(matchct12595)]
seer_ct_12596 = seer_ct[seer_ct["Census_Tract"].isin(matchct12596)]

lungnonex12513 = sum(seer_ct_12513["lung_corrected"]*weightct12513)/5
lungnonex12514 = sum(seer_ct_12514["lung_corrected"]*weightct12514)/5
lungnonex12584 = sum(seer_ct_12584["lung_corrected"]*weightct12584)/5
lungnonex12585 = sum(seer_ct_12585["lung_corrected"]*weightct12585)/5
lungnonex12586 = sum(seer_ct_12586["lung_corrected"]*weightct12586)/5
lungnonex12594 = sum(seer_ct_12594["lung_corrected"]*weightct12594)/5
lungnonex12595 = sum(seer_ct_12595["lung_corrected"]*weightct12595)/5
lungnonex12596 = sum(seer_ct_12596["lung_corrected"]*weightct12596)/5

seerdf = pd.DataFrame(utah, columns=["census_tract"])
seerdf["lungnonexposed"] = [lungnonex12513, lungnonex12514, lungnonex12584, lungnonex12585, lungnonex12586, lungnonex12594, lungnonex12595, lungnonex12596]

brainnonex12513 = sum(seer_ct_12513["brain_corrected"]*weightct12513)/5
brainnonex12514 = sum(seer_ct_12514["brain_corrected"]*weightct12514)/5
brainnonex12584 = sum(seer_ct_12584["brain_corrected"]*weightct12584)/5
brainnonex12585 = sum(seer_ct_12585["brain_corrected"]*weightct12585)/5
brainnonex12586 = sum(seer_ct_12586["brain_corrected"]*weightct12586)/5
brainnonex12594 = sum(seer_ct_12594["brain_corrected"]*weightct12594)/5
brainnonex12595 = sum(seer_ct_12595["brain_corrected"]*weightct12595)/5
brainnonex12596 = sum(seer_ct_12596["brain_corrected"]*weightct12596)/5

seerdf["brainnonexposed"]= [brainnonex12513, brainnonex12514, brainnonex12584, brainnonex12585, brainnonex12586, brainnonex12594, brainnonex12595, brainnonex12596]
seerdf["brainexposed"] = exposedct["braincorrected"].values
seerdf["lungexposed"] = exposedct["lungcorrected"].values
seerdf["Lung_cSIR"] = seerdf["lungexposed"]/ seerdf["lungnonexposed"]
seerdf["Brain_cSIR"] = seerdf["brainexposed"] / seerdf["brainnonexposed"]
'''

'''matchct12513 = ["Census Tract 141, Kings County, New York", "Census Tract 106, Whatcom County, Washington", "Census Tract 9701, Hickman County, Kentucky", "Census Tract 9702, Fremont County, Idaho", "Census Tract 17.66, Travis County, Texas"]
matchct12514 = ["Census Tract 272, Jefferson Parish, Louisiana", "Census Tract 105.01, Ouachita Parish, Louisiana", "Census Tract 94.04, Sacramento County, California", "Census Tract 18.13, Travis County, Texas", "Census Tract 9503, Lampasas County, Texas"]
matchct12584 = ["Census Tract 108.02, Hays County, Texas", "Census Tract 1469.01, Suffolk County, New York", "Census Tract 607.02, Saratoga County, New York", "Census Tract 1.05, Madera County, California", "Census Tract 202, Bell County, Texas"]
matchct12585 = ["Census Tract 9602, Idaho County, Idaho", "Census Tract 46, Bremer County, Iowa", "Census Tract 1006, Clinton County, New York", "Census Tract 201.03, San Diego County, California", "Census Tract 9637, La Salle County, Illinois"]
matchct12586 = ["Census Tract 93.01, Erie County, New York", "Census Tract 442, Riverside County, California", "Census Tract 3672, Contra Costa County, California", "Census Tract 4354, Alameda County, California", "Census Tract 1425, New Haven County, Connecticut"]
matchct12594 = ["Census Tract 8003.24, Los Angeles County, California", "Census Tract 320.53, Orange County, California", "Census Tract 319.02, Union County, New Jersey", "Census Tract 7329.01, Worcester County, Massachusetts", "Census Tract 29.04, Tulare County, California"]
matchct12595 = ["Census Tract 1130.01, Tarrant County, Texas", "Census Tract 6719, Fort Bend County, Texas", "Census Tract 19, Dona Ana County, New Mexico", "Census Tract 24, Queens County, New York", "Census Tract 8615.06, Lake County, Illinois"]
matchct12596 = ["Census Tract 102, Cumberland County, New Jersey", "Census Tract 1304.06, Johnson County, Texas", "Census Tract 1154.01, Los Angeles County, California", "Census Tract 7511, Worcester County, Massachusetts", "Census Tract 217.12, Denton County, Texas"]
'''