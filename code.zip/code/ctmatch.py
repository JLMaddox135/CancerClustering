import pandas as pd
import numpy as np
import scipy as stats
import math

# calculateMahalanobis function to calculate
# the Mahalanobis distance
def calculateMahalanobis(row1=None, row2=None, cov=None):
    x_y = row1[rest].values-row2[rest].values
    left = np.dot(x_y, cov)
    mahal = np.dot(left, x_y.T)
    return mahal.diagonal()

#Reading in data and constructing the Utah CT and US CT dataframes
total = pd.read_csv("/Users/7i3/Documents/Python/allUS.csv")
total['ct'] = total['Census_Tract'].str.extract('(\d+.?\d+|\d+)').astype('float64')
total = total[total['dioxin_exposure'] != 1]
ut = total[total["ct"].isin([1251.03, 1251.04, 1258.04, 1258.05, 1258.06, 1259.04, 1259.05, 1259.06])]
usct =total[(total["ct"]).isin([1251.03, 1251.04, 1258.04, 1258.05, 1258.06, 1259.04, 1259.05, 1259.06]) == False]
usct = total

#Covariates to compare CTs on
rest = ['Total_Pop','Male_Percent', 'Female_Percent','Pop_25+', 'Percent_HSGrad_Pop_25+', 'Pop_16+','Percent_Labor_Force_Pop_16+', 'Percent_Civillian_Labor_Force_Pop_16+','Percent_Employed', 'Percent_Unemployed', 'Workers_16+',\
    'Mean_Travel_Time', 'Agriculture_Percent', 'Construction_Percent','Manufacturing_Percent', 'Households', 'Median_household_income','Mean_earnings', 'Percent_Below_Poverty_Level','Percent_Below_Poverty_Level_18+', 
    'Percent_Below_Poverty_Level_65+','White_alone', 'Asian_alone', 'Black_or_African_American_alone','American_Indian_and_Alaska_Native_alone','Native_Hawaiian_and_Other_Pacific_Islander_alone','Some_other_race_alone', 'Two_or_more_races', 'Urban', 'Rural']

state = ["California", "Connecticut", "Hawaii", "Iowa", "New Mexico", "Washington", "Utah", "Georgia", "Texas", "Kentucky", "Louisiana", "New Jersey", "Idaho", "New York", "Massachusetts", "Illinois"]

#Dropping Na Rows and Unamed Columns
total = total.dropna(subset=rest, axis = 0)
total.drop('Unnamed: 0', axis = 1, inplace = True)
ut.drop('Unnamed: 0', axis = 1, inplace = True)
usct.drop('Unnamed: 0', axis = 1, inplace = True)
usct = usct.dropna(subset = rest, axis = 0)

test1 = usct["Census_Tract"].str.extract(', (\w+ \w+ \w+|\w+ \w+), (\w+ \w+|\w+)')
usct["state"] = test1[1]

usct = usct[usct["state"].isin(state)]


#Reseting indexes
ut = ut.reset_index()
ut.drop('index', axis = 1, inplace = True)
usct = usct.reset_index()
usct.drop('index', axis = 1, inplace = True)



#Calculating covariance matrix using total dataset
covtot = np.cov(total[rest].values.T)
invcovtot = np.linalg.inv(covtot)

usct['1251.03'] = usct[rest].apply(calculateMahalanobis, row2 = ut[ut['ct'] == 1251.03], cov = invcovtot, axis=1).abs()
usct['1251.04'] = usct[rest].apply(calculateMahalanobis, row2 = ut[ut['ct'] == 1251.04], cov = invcovtot, axis=1).abs()
usct['1258.04'] = usct[rest].apply(calculateMahalanobis, row2 = ut[ut['ct'] == 1258.04], cov = invcovtot, axis=1).abs()
usct['1258.05'] = usct[rest].apply(calculateMahalanobis, row2 = ut[ut['ct'] == 1258.05], cov = invcovtot, axis=1).abs()
usct['1258.06'] = usct[rest].apply(calculateMahalanobis, row2 = ut[ut['ct'] == 1258.06], cov = invcovtot, axis=1).abs()
usct['1259.04'] = usct[rest].apply(calculateMahalanobis, row2 = ut[ut['ct'] == 1259.04], cov = invcovtot, axis=1).abs()
usct['1259.05'] = usct[rest].apply(calculateMahalanobis, row2 = ut[ut['ct'] == 1259.05], cov = invcovtot, axis=1).abs()
usct['1259.06'] = usct[rest].apply(calculateMahalanobis, row2 = ut[ut['ct'] == 1259.06], cov = invcovtot, axis=1).abs()

match125103 = usct[["Census_Tract", '1251.03']]
match125103 = match125103.sort_values(by = ['1251.03'])
match125103 = match125103.reset_index()
match125104 = usct[["Census_Tract", '1251.04']]
match125104 = match125104.sort_values(by = ['1251.04'])
match125804 = usct[["Census_Tract", '1258.04']]
match125804 = match125804.sort_values(by = ['1258.04'])
match125805 = usct[["Census_Tract", '1258.05']]
match125805 = match125805.sort_values(by = ['1258.05'])
match125806 = usct[["Census_Tract", '1258.06']]
match125806 = match125806.sort_values(by = ['1258.06'])
match125904 = usct[["Census_Tract", '1259.04']]
match125904 = match125904.sort_values(by = ['1259.04'])
match125905 = usct[["Census_Tract", '1259.05']]
match125905 = match125905.sort_values(by = ['1259.05'])
match125906 = usct[["Census_Tract", '1259.06']]
match125906 = match125906.sort_values(by = ['1259.06'])
match125104 = match125104[match125104["Census_Tract"] != "Census Tract 17, Yakima County, Washington"]
match125804 = match125804[match125804["Census_Tract"] != 'Census Tract 102.02, Spokane County, Washington']
matchnum = 10

mat13 = match125103["Census_Tract"][0:matchnum]
mat14 = match125104["Census_Tract"][0:matchnum]
mat84 = match125804["Census_Tract"][0:matchnum]
mat85 = match125805["Census_Tract"][0:matchnum]
mat86 = match125806["Census_Tract"][0:matchnum]
mat94 = match125904["Census_Tract"][0:matchnum]
mat95 = match125905["Census_Tract"][0:matchnum]
mat96 = match125906["Census_Tract"][0:matchnum]
mattot = pd.concat([mat13, mat14, mat84, mat85, mat86, mat94, mat95, mat96])

mat13.to_csv("/Users/7i3/Documents/Python/mat13.csv")
mat14.to_csv("/Users/7i3/Documents/Python/mat14.csv")
mat84.to_csv("/Users/7i3/Documents/Python/mat84.csv")
mat85.to_csv("/Users/7i3/Documents/Python/mat85.csv")
mat86.to_csv("/Users/7i3/Documents/Python/mat86.csv")
mat94.to_csv("/Users/7i3/Documents/Python/mat94.csv")
mat95.to_csv("/Users/7i3/Documents/Python/mat95.csv")
mat96.to_csv("/Users/7i3/Documents/Python/mat96.csv")
mattot.to_csv("/Users/7i3/Documents/Python/mattot.csv")


#calculateMahalanobis(row1 = usct[usct['id'] == 1003011202], row2 = ut[ut['ct'] == 1251.03], cov=invcovtot)

usct.sort_values(by = ['1251.03'])[['Census_Tract','1251.03']].head(n=20)
usct.sort_values(by = ['1251.04'])[['Census_Tract','1251.04']].head(n=20)
usct.sort_values(by = ['1258.04'])[['Census_Tract','1258.04']].head(n=20)
usct.sort_values(by = ['1258.05'])[['Census_Tract','1258.05']].head(n=25)
usct.sort_values(by = ['1258.06'])[['Census_Tract','1258.06']].head(n=10)
usct.sort_values(by = ['1259.04'])[['Census_Tract','1259.04']].head(n=10)
usct.sort_values(by = ['1259.05'])[['Census_Tract','1259.05']].head(n=10)
usct.sort_values(by = ['1259.06'])[['Census_Tract','1259.06']].head(n=15)



""" #for loop to iterate through all utah cts to match too
for i in ut['id']:

    #setting the utah id that is being compared
    xx = ut[ut['id'] == i][rest]

    #Resetting all minimum mahalanobis distances (only did the top 3 because computer couldn't handle storing all of them)
    #Now that i think about it I may have been storing them improperly and taking up too much space in memory
    min1 = 9999999999999
    min2 = 9999999999999
    min3 = 9999999999999

    #for loop through all us cts
    for j in usct['id']:
        #Setting the usct that is being compared to xx
        yy = usct[usct['id'] == j][rest]

        #calculate mahalanobis distance
        mah = float(calculateMahalanobis(x = xx, y = yy, data = total[rest], cov = covtot))

        #Compare to minimum 1 and update if less
        if(mah < min1):
            print(mah)
            min3 = min2
            min2 = min1
            min1 = mah
            id3 = id2
            id2 = id1
            id1 = j
    #afterwards form a df to store all information about the best minimums for the ut cts
    if i == 1:
        df = pd.DataFrame([[i, min1, min2, min3, id1, id2, id3]],columns=['id','min1','min2', 'min3', 'id1', 'id2', 'id3'])
    else:
        df2 = pd.DataFrame([[i, min1, min2, min3, id1, id2, id3]],columns=['id','min1','min2', 'min3', 'id1', 'id2', 'id3'])
        df = df.append(df2) """




