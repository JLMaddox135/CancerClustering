import math
from msilib import sequence
import string
import matplotlib
import numpy as np
import pandas as pd
import scipy as sp
import sklearn.tree as skt
import sklearn.ensemble as ske
import sklearn.model_selection as skms
import sklearn.metrics as skmet
from sklearn import linear_model
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
from sklearn.model_selection import KFold
import matplotlib.pyplot as plt
import seaborn as sns
import shap

plt.style.use('ggplot')
plt.show()

allus = pd.read_csv("allus.csv", dtype={'id': str})
allus = allus.drop("Unnamed: 0", axis =1)

rest = ['Total_Pop','Male_Percent', 'Female_Percent','Pop_25+', 'Percent_HSGrad_Pop_25+', 'Pop_16+','Percent_Labor_Force_Pop_16+', 'Percent_Civillian_Labor_Force_Pop_16+','Percent_Employed', 'Percent_Unemployed', 'Workers_16+',\
    'Mean_Travel_Time', 'Agriculture_Percent', 'Construction_Percent','Manufacturing_Percent', 'Households', 'Median_household_income','Mean_earnings', 'Percent_Below_Poverty_Level','Percent_Below_Poverty_Level_18+', 
    'Percent_Below_Poverty_Level_65+','White_alone', 'Asian_alone', 'Black_or_African_American_alone','American_Indian_and_Alaska_Native_alone','Native_Hawaiian_and_Other_Pacific_Islander_alone','Some_other_race_alone', 'Two_or_more_races',
    'Urban', 'Rural']

restd = ['Total_Pop','Male_Percent', 'Female_Percent','Pop_25+', 'Percent_HSGrad_Pop_25+', 'Pop_16+','Percent_Labor_Force_Pop_16+', 'Percent_Civillian_Labor_Force_Pop_16+','Percent_Employed', 'Percent_Unemployed', 'Workers_16+',\
    'Mean_Travel_Time', 'Agriculture_Percent', 'Construction_Percent','Manufacturing_Percent', 'Households', 'Median_household_income','Mean_earnings', 'Percent_Below_Poverty_Level','Percent_Below_Poverty_Level_18+', 
    'Percent_Below_Poverty_Level_65+','White_alone', 'Asian_alone', 'Black_or_African_American_alone','American_Indian_and_Alaska_Native_alone','Native_Hawaiian_and_Other_Pacific_Islander_alone','Some_other_race_alone', 'Two_or_more_races',
    'Urban', 'Rural', 'dioxin_exposure']

restc = ['Total_Pop','Male_Percent', 'Female_Percent','Pop_25+', 'Percent_HSGrad_Pop_25+', 'Pop_16+','Percent_Labor_Force_Pop_16+', 'Percent_Civillian_Labor_Force_Pop_16+','Percent_Employed', 'Percent_Unemployed', 'Workers_16+',\
    'Mean_Travel_Time', 'Agriculture_Percent', 'Construction_Percent','Manufacturing_Percent', 'Households', 'Median_household_income','Mean_earnings', 'Percent_Below_Poverty_Level','Percent_Below_Poverty_Level_18+', 
    'Percent_Below_Poverty_Level_65+','White_alone', 'Asian_alone', 'Black_or_African_American_alone','American_Indian_and_Alaska_Native_alone','Native_Hawaiian_and_Other_Pacific_Islander_alone','Some_other_race_alone', 'Two_or_more_races',
    'Urban', 'Rural', 'dioxin_exposure', 'observed_Lung', 'observed_Brain']

percent = ['Male_Percent', 'Female_Percent', 'Percent_HSGrad_Pop_25+', 'Percent_Labor_Force_Pop_16+', 'Percent_Civillian_Labor_Force_Pop_16+','Percent_Employed', 'Percent_Unemployed',\
    'Agriculture_Percent', 'Construction_Percent','Manufacturing_Percent', 'Percent_Below_Poverty_Level','Percent_Below_Poverty_Level_18+', 
    'Percent_Below_Poverty_Level_65+','White_alone', 'Asian_alone', 'Black_or_African_American_alone','American_Indian_and_Alaska_Native_alone','Native_Hawaiian_and_Other_Pacific_Islander_alone','Some_other_race_alone', 'Two_or_more_races',
    'Urban', 'Rural']

#########################################################

allus = allus.dropna(axis = 0, subset = rest)
ny = allus.dropna(axis = 0, subset=['observed_Brain', 'expected_Brain', 'highlight_Brain', 'observed_Lung', 'expected_Lung', 'highlight_Lung'])
#ny['LungPC'] = ny['observed_Lung']/ny['Total_Pop']
#ny['BrainPC'] = ny['observed_Brain']/ny['Total_Pop']
df = ny[rest]
#y = ny[['observed_Brain', 'expected_Brain', 'highlight_Brain', 'observed_Lung', 'expected_Lung', 'highlight_Lung']]
y = ny[['LungPC']]

#PCA
#################################################################
X = df.values
X.shape
scaler = StandardScaler()
scaler.fit(X)
X_scaled = scaler.transform(X)

pca_31 = PCA(n_components = 31)
pca_31.fit(X_scaled)
X_pca_31 = pca_31.transform(X_scaled)

pca_31.explained_variance_ratio_ * 100
np.cumsum(pca_31.explained_variance_ratio_ * 100)

print("Variance explained by the First principal component =", 
    np.cumsum(pca_31.explained_variance_ratio_ * 100)[0])
print("Variance explained by the First 2 principal components =", 
    np.cumsum(pca_31.explained_variance_ratio_ * 100)[1])
print("Variance explained by the First 3 principal components =", 
    np.cumsum(pca_31.explained_variance_ratio_ * 100)[2])
print("Variance explained by the First 14 principal components =", 
    np.cumsum(pca_31.explained_variance_ratio_ * 100)[15])


pca_15 = PCA(n_components = 16)
pca_15.fit(X_scaled)
X_pca_15 = pca_15.transform(X_scaled)

pca_15.explained_variance_ratio_ * 100
np.cumsum(pca_15.explained_variance_ratio_ * 100)

print("Variance explained by the First principal component =", 
    np.cumsum(pca_15.explained_variance_ratio_ * 100)[0])
print("Variance explained by the First 2 principal components =", 
    np.cumsum(pca_15.explained_variance_ratio_ * 100)[1])
print("Variance explained by the First 3 principal components =", 
    np.cumsum(pca_15.explained_variance_ratio_ * 100)[2])
print("Variance explained by the First 16 principal components =", 
    np.cumsum(pca_15.explained_variance_ratio_ * 100)[15])

df_new = pd.DataFrame(X_pca_15, columns=['PC1', 'PC2', 'PC3', 'PC4', 'PC5', 'PC6', 'PC7', 'PC8', 'PC9', 'PC10', 'PC11', 'PC12', 'PC13', 'PC14', 'PC15', 'PC16'])
#df_new = pd.DataFrame(X_pca_15, columns=['PC1', 'PC2', 'PC3', 'PC4'])

######################################################
#Model Evaluation
######################################################

#nybl = pd.read_csv('ny_blcancer.csv', dtype={'geoid10': str})
#nybl = nybl.drop("Unnamed: 0", axis =1)
#nybl['id'] = nybl['geoid10'].str[:11]
#temp = nybl['id'].values
#ny2 = allus[allus['id'].isin(nybl['id'])]

# Need to load JS vis in the notebook
shap.initjs()

allus = allus.dropna(axis = 0, subset = rest)
ny = allus.dropna(axis = 0, subset=['observed_Brain', 'expected_Brain', 'highlight_Brain', 'observed_Lung', 'expected_Lung', 'highlight_Lung'])
#ny['LungPC'] = ny['observed_Lung']/ny['Total_Pop']
#ny['BrainPC'] = ny['observed_Brain']/ny['Total_Pop']
X = ny[rest]
y = ny[['observed_Lung']]
#linear_model.Lasso(alpha=1)
#skt.DecisionTreeRegressor(max_depth=5) 
list = [ske.GradientBoostingRegressor(), ske.AdaBoostRegressor(), ske.BaggingRegressor(), ske.ExtraTreesRegressor(), ske.HistGradientBoostingRegressor(), ske.RandomForestRegressor()]

X_train, X_test, y_train, y_test = skms.train_test_split(X, y, test_size=0.2, train_size=0.8)
for i in list:
    reg = i
    est = reg.fit(X_train, y_train.values.ravel())
    explainer = shap.TreeExplainer(est)
    shap_values = explainer.shap_values(X_train)
    shap.summary_plot(shap_values, features=X_train, feature_names=X_train.columns)
    temp = est.predict(X_test)
    skmet.mean_squared_error(y_test, temp)
    reg.score(X_test, y_test)

#########################
#Lasso model use
#########################

allus = allus.dropna(axis = 0, subset = restd)
ny = allus.dropna(axis = 0, subset=['observed_Brain', 'expected_Brain', 'highlight_Brain', 'observed_Lung', 'expected_Lung', 'highlight_Lung'])
#ny['LungPC'] = ny['observed_Lung']/ny['Total_Pop']
#ny['BrainPC'] = ny['observed_Brain']/ny['Total_Pop']
X = ny[rest]
y = ny[['observed_Brain']]

for i in range(1, 1001):
    X_train, X_test, y_train, y_test = skms.train_test_split(X, y, test_size=0.2, train_size=0.8)
    reg = linear_model.Lasso(alpha=0.1)
    est = reg.fit(X_train, y_train.values.ravel())
    temp = est.predict(X_test)
    if(i == 1):
        sum = reg.coef_
        sumscore = reg.score(X_test, y_test)
        summse = skmet.mean_squared_error(y_test, temp)
        histdat = np.where(sum != 0, 1, 0)
    else:
        sum = sum + reg.coef_
        sumscore = sumscore + reg.score(X_test, y_test)
        summse = summse + skmet.mean_squared_error(y_test, temp)
        histdat = histdat + np.where(sum != 0, 1, 0)

avg = sum/1000
avgscore = sumscore/1000
avgmse = summse/1000

df_coef = pd.DataFrame(avg.reshape(-1, len(avg)), columns = X_test.columns)
df_hist = pd.DataFrame(histdat.reshape(-1, len(histdat)), columns = X_test.columns)
df_coef = df_coef.loc[:, (df_coef != 0).any(axis=0)]
tempcol = X_test.columns.difference(df_coef.columns).tolist()

df_hist2 = pd.DataFrame.transpose(df_hist)
df_hist2.columns = ['count']
df_hist2.index.name = 'head'
df_hist2.reset_index(inplace = True)
df_hist2 = df_hist2.sort_values('count')


df_hist2.plot.bar(x = 'head', y = 'count')
plt.autoscale()
plt.show()

##############################
#Covariance Heat plot
##############################
plt.figure(figsize=(17, 8))
nycolreduced = ny[restc]

nycolreduced.columns = ['Total_Pop', 'Male_Percent', 'Female_Percent', 'Pop_25+', 'Percent_HS_Grad', 'Pop_16+', 'Percent_Labor_Force', 'Percent_Civilian_Labor_Force',\
    'Percent_Employed', 'Percent_Unemployed', 'Workers_16+','Mean_Travel_Time', 'Agriculture_Percent', 'Construction_Percent','Manufacturing_Percent', 'Households', 'Median_household_income',
    'Mean_earnings', 'Percent_Below_Poverty_Level', 'Percent_Below_Poverty_Level_18+','Percent_Below_Poverty_Level_65+', 'White_alone', 'Asian_alone', 'Black_alone', 'Native_American_Alone',
    'Pacific_Islander_alone', 'Some_other_race_alone', 'Two_or_more_races', 'Urban', 'Rural','observed_Lung', 'observed_Brain']
nycancer = nycolreduced
mask = np.triu(np.ones_like(nycancer.corr(), dtype=np.bool))
heatmap = sns.heatmap(nycancer.corr(), vmin=-1, vmax=1, mask=mask, annot=True, annot_kws={"size":6}, cmap='BrBG')
heatmap.set_title('Correlation Heatmap', fontdict={'fontsize':12}, pad=12)
fig = heatmap.get_figure()
fig.savefig('/Users/7i3/Documents/Python/heatmapallus.png', bbox_inches='tight')
plt.close(fig)

plt.show()
##############################

#Manual feature dropping
##############################
allus = allus.dropna(axis = 0, subset = rest)
ny = allus.dropna(axis = 0, subset=['observed_Brain', 'expected_Brain', 'highlight_Brain', 'observed_Lung', 'expected_Lung', 'highlight_Lung'])
X = df_new
#y = ny[['observed_Brain', 'expected_Brain', 'highlight_Brain', 'observed_Lung', 'expected_Lung', 'highlight_Lung']]
y = ny[['observed_Lung']]

X_train, X_test, y_train, y_test = skms.train_test_split(X, y, test_size=0.2, train_size=0.8)
reg = ske.GradientBoostingRegressor()
est = reg.fit(X_train, y_train.values.ravel())
r2 = reg.score(X_test, y_test)
temp = est.predict(X_test)
skmet.mean_squared_error(y_test, temp)
n = X_test.shape[0]
p = X_train.shape[1]
adj_r2 = 1-(1-r2)*(n-1)/(n-p-1)
print(r2)
print(adj_r2)

tmp1 = X_train
tmp2 = X_test
results = [adj_r2]
titles = ['No_Col_Drop']
for i in range(0, X_train.shape[1]):
    #print(tmp1.columns)
    tmp1.drop(tmp1.columns[i], axis = 1)
    tmp2.drop(tmp2.columns[i], axis = 1)
    reg = ske.GradientBoostingRegressor()
    est = reg.fit(tmp1, y_train.values.ravel())
    r2 = reg.score(tmp2, y_test)
    n = tmp1.shape[0]
    p = tmp1.shape[1]
    adj_r2 = 1-(1-r2)*(n-1)/(n-p-1)
    results.append(adj_r2)
    titles.append(tmp1.columns[i])
    tmp1 = X_train
    tmp2 = X_test

df = pd.DataFrame()
df['removed_col'] = titles
df['adj_r2'] = results

dfGBR = df.sort_values(by = ['adj_r2'])


