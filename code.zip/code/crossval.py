import math
from msilib import sequence
from pickle import TRUE
import string
import matplotlib
import numpy as np
import pandas as pd
import scipy as sp
import sklearn.tree as skt
import sklearn.ensemble as ske
import sklearn.model_selection as skms
import sklearn.metrics as skmet
from sklearn import linear_model
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
from sklearn.model_selection import KFold, cross_val_score, cross_validate
import matplotlib.pyplot as plt
import seaborn as sns
import shap

allus = pd.read_csv("allus.csv", dtype={'id': str})
allus = allus.drop("Unnamed: 0", axis =1)

rest = ['Total_Pop','Male_Percent', 'Female_Percent','Pop_25+', 'Percent_HSGrad_Pop_25+', 'Pop_16+','Percent_Labor_Force_Pop_16+', 'Percent_Civillian_Labor_Force_Pop_16+','Percent_Employed', 'Percent_Unemployed', 'Workers_16+',\
    'Mean_Travel_Time', 'Agriculture_Percent', 'Construction_Percent','Manufacturing_Percent', 'Households', 'Median_household_income','Mean_earnings', 'Percent_Below_Poverty_Level','Percent_Below_Poverty_Level_18+', 
    'Percent_Below_Poverty_Level_65+','White_alone', 'Asian_alone', 'Black_or_African_American_alone','American_Indian_and_Alaska_Native_alone','Native_Hawaiian_and_Other_Pacific_Islander_alone','Some_other_race_alone', 'Two_or_more_races',
    'Urban', 'Rural']

allus = allus.dropna(axis = 0, subset = rest)
ny = allus.dropna(axis = 0, subset=['observed_Brain', 'expected_Brain', 'highlight_Brain', 'observed_Lung', 'expected_Lung', 'highlight_Lung'])
list = [ske.GradientBoostingRegressor(), ske.AdaBoostRegressor(), ske.BaggingRegressor(), ske.ExtraTreesRegressor(), ske.HistGradientBoostingRegressor(), ske.RandomForestRegressor()]

X = ny[rest]
y = ny[['observed_Brain']]

scores = {'r2score': 'r2', 'mse':'neg_mean_squared_error' }
for i in list:
    reg = i
    cvs = cross_validate(reg, X, y.values.ravel(), scoring=scores, cv=5, return_train_score=True)
    dfcvs = pd.DataFrame.from_dict(cvs)
    print(dfcvs[['test_r2score', 'test_mse']])
    print(dfcvs["test_r2score"].mean())
    print(dfcvs["test_mse"].mean())
