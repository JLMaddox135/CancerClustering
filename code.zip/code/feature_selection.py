import math
from msilib import sequence
import string
import matplotlib
import numpy as np
import pandas as pd
import scipy as sp
import sklearn.tree as skt
import sklearn.ensemble as ske
import sklearn.model_selection as skms
import sklearn.metrics as skmet
from sklearn import linear_model
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
import matplotlib.pyplot as plt
import seaborn as sns
import shap
from itertools import chain, combinations

plt.style.use('ggplot')
plt.show()

allus = pd.read_csv("allus.csv", dtype={'id': str})
allus = allus.drop("Unnamed: 0", axis =1)

feat1 = ['Total_Pop', 'Male_Percent', 'Female_Percent', 'Pop_25+','Percent_HSGrad_Pop_25+', 'Pop_16+', 'Percent_Labor_Force_Pop_16+','Percent_Civillian_Labor_Force_Pop_16+', 'Percent_Employed',\
    'Mean_Travel_Time', 'Construction_Percent', 'Manufacturing_Percent','Households', 'Median_household_income', 'Mean_earnings','Percent_Below_Poverty_Level', 'Percent_Below_Poverty_Level_18+',
    'Percent_Below_Poverty_Level_65+', 'White_alone', 'Asian_alone','Black_or_African_American_alone', 'Some_other_race_alone','Two_or_more_races', 'Urban', 'Rural']

feat_order = ['Male_Percent', 'Female_Percent', 'Percent_Civillian_Labor_Force_Pop_16+', 'Percent_Below_Poverty_Level_18+', 'Manufacturing_Percent', 'Percent_Below_Poverty_Level_65+',\
    'Asian_alone', 'Mean_Travel_Time', 'Two_or_more_races', 'Households', 'Construction_Percent', 'Pop_16+', 'Median_household_income', 'Percent_Below_Poverty_Level', 'Mean_earnings',
    'Percent_HSGrad_Pop_25+', 'Rural', 'Some_other_race_alone', 'Urban', 'Percent_Labor_Force_Pop_16+', 'Pop_25+', 'Black_or_African_American_alone', 'Percent_Employed', 'White_alone',
    'Total_Pop']

allus = allus.dropna(axis = 0, subset = feat1)
ny = allus.dropna(axis = 0, subset=['observed_Brain', 'expected_Brain', 'highlight_Brain', 'observed_Lung', 'expected_Lung', 'highlight_Lung'])

nycancer = ny[["observed_Brain", "observed_Lung"]]
nycancer = nycancer.reset_index()
nycancer = nycancer[["observed_Brain", "observed_Lung"]]
sns.kdeplot(nycancer["observed_Lung"])

X = ny[feat1]
y = ny[['observed_Brain']]
#mllist = [ske.GradientBoostingRegressor(), ske.AdaBoostRegressor(), ske.BaggingRegressor(), ske.ExtraTreesRegressor(), ske.HistGradientBoostingRegressor(), ske.RandomForestRegressor()]

X_train, X_test, y_train, y_test = skms.train_test_split(X, y, test_size=0.2, train_size=0.8)
reg = ske.GradientBoostingRegressor()
est = reg.fit(X_train, y_train.values.ravel())
r2 = reg.score(X_test, y_test)
temp = est.predict(X_test)
skmet.mean_squared_error(y_test, temp)
n = X_test.shape[0]
p = X_train.shape[1]
adj_r2 = 1-(1-r2)*(n-1)/(n-p-1)
print(r2)
print(adj_r2)

tmp1 = X_train
tmp2 = X_test
results = [adj_r2]
titles = ['No_Col_Drop']
cols_removed = [0]

tmp1 = X_train
tmp2 = X_test
for i in range(0, 24):
    tmp1=tmp1.drop(feat_order[i], axis = 1)
    tmp2=tmp2.drop(feat_order[i], axis = 1)
    reg = ske.GradientBoostingRegressor()
    est = reg.fit(tmp1, y_train.values.ravel())
    r2 = reg.score(tmp2, y_test)
    n = tmp1.shape[0]
    p = tmp1.shape[1]
    adj_r2 = 1-(1-r2)*(n-1)/(n-p-1)
    results.append(adj_r2)
    titles.append(feat_order[i])
    cols_removed.append(i+1)

df = pd.DataFrame()
df['removed_col'] = titles
df['adj_r2'] = results
df['cols_removed'] = cols_removed



#Ordering features
for i in range(1, 1001):
    X_train, X_test, y_train, y_test = skms.train_test_split(X, y, test_size=0.2, train_size=0.8)
    reg = ske.GradientBoostingRegressor()
    est = reg.fit(X_train, y_train.values.ravel())
    explainer = shap.TreeExplainer(est)
    temp = est.predict(X_test)
    if(i == 1):
        shap_values = explainer.shap_values(X_train)
        sumscore = reg.score(X_test, y_test)
        summse = skmet.mean_squared_error(y_test, temp)
    elif(i != 1):
        shap_values = shap_values + explainer.shap_values(X_train)
        sumscore = sumscore + reg.score(X_test, y_test)
        summse = summse + skmet.mean_squared_error(y_test, temp)

shap_values = shap_values/1000
avgscore = sumscore/1000
avgmse = summse/1000

shap.summary_plot(shap_values, features=X_train, feature_names=X_train.columns, max_display=25)


""" for i in mllist:
    reg = i
    est = reg.fit(X_train, y_train.values.ravel())
    #explainer = shap.TreeExplainer(est)
    #shap_values = explainer.shap_values(X_train)
    #shap.summary_plot(shap_values, features=X_train, feature_names=X_train.columns)
    temp = est.predict(X_test)
    skmet.mean_squared_error(y_test, temp)
    reg.score(X_test, y_test) """



