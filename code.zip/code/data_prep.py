import math
import pandas as pd
import numpy as np

def to_bool(s):
    return 1 if s == "True" else 0

eco = pd.read_excel('ECONOMICS_ALLUS.xlsx')
dem = pd.read_excel('Demographic_ALLUS.xlsx')
house = pd.read_excel('HOUSING_ALLUS.xlsx')
race = pd.read_excel('RACE_ALLUS.xlsx')
edu = pd.read_excel('Education_ALLUS.xlsx')
diox = pd.read_excel('us_dioxin_1982-2020.xlsx', converters = {'geoid':str})
nybl = pd.read_csv("ny_blcancer.csv")

diox["geoid"] = diox['geoid'].str[:11]
nybl = nybl.drop("Unnamed: 0", axis =1)
nybl = nybl.loc[:, ['geoid10', 'observed_Brain', 'expected_Brain', 'highlight_Brain', 'observed_Lung', 'expected_Lung', 'highlight_Lung']]
nybl['geoid'] = nybl['geoid10'].str[:11]
nybl2 = nybl.groupby('geoid')['observed_Brain', 'expected_Brain', 'highlight_Brain', 'observed_Lung', 'expected_Lung', 'highlight_Lung'].sum()

eco.columns = [c.replace(' ', '_') for c in eco.columns]
dem.columns = [c.replace(' ', '_') for c in dem.columns]
house.columns = [c.replace(' ', '_') for c in house.columns]
race.columns = [c.replace(' ', '_') for c in race.columns]
edu.columns = [c.replace(' ', '_') for c in edu.columns]


#edhredu.loc[edhredu['Geographic_Area_Name'] == "Census Tract 601, Washington County, Tennessee"]

ecodem = pd.merge(left = eco, right = dem, on = "Geographic_Area_Name")
edhouse = pd.merge(left = ecodem, right = house, left_on = "Geographic_Area_Name", right_on="Label_for_GEO_ID")
edhrace = pd.merge(left = edhouse, right = race, left_on = "Geographic_Area_Name", right_on="Label_for_GEO_ID" )
edhredu = pd.merge(left = edhrace, right = edu, on = "Geographic_Area_Name")

df = edhredu[["Geographic_Area_Name", "id", "Total_y", "Percent!!Total_population!!SEX_AND_AGE!!Male", "Percent!!Total_population!!SEX_AND_AGE!!Female", \
    "Number!!EDUCATIONAL_ATTAINMENT!!Population_25_years_and_over", "Number!!EDUCATIONAL_ATTAINMENT!!Population_25_years_and_over!!Percent_high_school_graduate_or_higher", 
    "Number!!EMPLOYMENT_STATUS!!Population_16_years_and_over","Number!!EMPLOYMENT_STATUS!!Population_16_years_and_over!!In_labor_force", "Percent!!EMPLOYMENT_STATUS!!Population_16_years_and_over!!In_labor_force" , "Percent!!EMPLOYMENT_STATUS!!Population_16_years_and_over!!In_labor_force!!Civilian_labor_force",
    "Percent!!EMPLOYMENT_STATUS!!Population_16_years_and_over!!In_labor_force!!Civilian_labor_force!!Employed", "Percent!!EMPLOYMENT_STATUS!!Population_16_years_and_over!!In_labor_force!!Civilian_labor_force!!Unemployed",
    "Number!!COMMUTING_TO_WORK!!Workers_16_years_and_over", "Number!!COMMUTING_TO_WORK!!Workers_16_years_and_over!!Mean_travel_time_to_work_(minutes)", 
    "Percent!!Employed_civilian_population_16_years_and_over!!INDUSTRY!!Agriculture,_forestry,_fishing_and_hunting,_and_mining", "Percent!!Employed_civilian_population_16_years_and_over!!INDUSTRY!!Construction", "Percent!!Employed_civilian_population_16_years_and_over!!INDUSTRY!!Manufacturing",
    "Number!!INCOME_IN_1999!!Households", "Number!!INCOME_IN_1999!!Households!!Median_household_income_(dollars)", "Number!!INCOME_IN_1999!!Households!!With_earnings!!Mean_earnings_(dollars)",
    "Percent!!POVERTY_STATUS_IN_1999_(below_poverty_level)!!Individuals!!Percent_below_poverty_level", "Percent!!POVERTY_STATUS_IN_1999_(below_poverty_level)!!Individuals!!18_years_and_over!!Percent_below_poverty_level",
    "Percent!!POVERTY_STATUS_IN_1999_(below_poverty_level)!!Individuals!!18_years_and_over!!65_years_and_over!!Percent_below_poverty_level", "Total!!White_alone", 
    "Total!!Asian_alone", "Total!!Black_or_African_American_alone", "Total!!American_Indian_and_Alaska_Native_alone", "Total!!Native_Hawaiian_and_Other_Pacific_Islander_alone",
    "Total!!Some_other_race_alone", "Total!!Two_or_more_races", "Total!!Urban", "Total!!Rural"]]

df = df[df['Geographic_Area_Name'] != 'United States'] # we don't really care about US data, just these census tracts

df['id'] = df['id'].str[9:]

#df[["Geographic_Area_Name"]] = df.Geographic_Area_Name.str.extract('(\d+\.\d+|\d+)')

df2 = df.rename({'Geographic_Area_Name': "Census_Tract", "Total_y": "Total_Pop", "Percent!!Total_population!!SEX_AND_AGE!!Male": "Male_Percent", \
    "Percent!!Total_population!!SEX_AND_AGE!!Female": "Female_Percent", "Number!!EDUCATIONAL_ATTAINMENT!!Population_25_years_and_over": "Pop_25+", 
    "Number!!EDUCATIONAL_ATTAINMENT!!Population_25_years_and_over!!Percent_high_school_graduate_or_higher": "Percent_HSGrad_Pop_25+", "Number!!EMPLOYMENT_STATUS!!Population_16_years_and_over": "Pop_16+",
    "Number!!EMPLOYMENT_STATUS!!Population_16_years_and_over!!In_labor_force": "Labor_Force_Pop_16+","Percent!!EMPLOYMENT_STATUS!!Population_16_years_and_over!!In_labor_force": "Percent_Labor_Force_Pop_16+", "Percent!!EMPLOYMENT_STATUS!!Population_16_years_and_over!!In_labor_force!!Civilian_labor_force": "Percent_Civillian_Labor_Force_Pop_16+",
    "Percent!!EMPLOYMENT_STATUS!!Population_16_years_and_over!!In_labor_force!!Civilian_labor_force!!Employed": "Percent_Employed", "Percent!!EMPLOYMENT_STATUS!!Population_16_years_and_over!!In_labor_force!!Civilian_labor_force!!Unemployed": "Percent_Unemployed",
    "Number!!COMMUTING_TO_WORK!!Workers_16_years_and_over": "Workers_16+", "Number!!COMMUTING_TO_WORK!!Workers_16_years_and_over!!Mean_travel_time_to_work_(minutes)": "Mean_Travel_Time",
    "Percent!!Employed_civilian_population_16_years_and_over!!INDUSTRY!!Agriculture,_forestry,_fishing_and_hunting,_and_mining": "Agriculture_Percent", "Percent!!Employed_civilian_population_16_years_and_over!!INDUSTRY!!Construction": "Construction_Percent",
    "Percent!!Employed_civilian_population_16_years_and_over!!INDUSTRY!!Manufacturing": "Manufacturing_Percent", "Number!!INCOME_IN_1999!!Households": "Households", 
    "Number!!INCOME_IN_1999!!Households!!Median_household_income_(dollars)": "Median_household_income", "Number!!INCOME_IN_1999!!Households!!With_earnings!!Mean_earnings_(dollars)": "Mean_earnings",
    "Percent!!POVERTY_STATUS_IN_1999_(below_poverty_level)!!Individuals!!Percent_below_poverty_level": "Percent_Below_Poverty_Level", "Percent!!POVERTY_STATUS_IN_1999_(below_poverty_level)!!Individuals!!18_years_and_over!!Percent_below_poverty_level": "Percent_Below_Poverty_Level_18+",
    "Percent!!POVERTY_STATUS_IN_1999_(below_poverty_level)!!Individuals!!18_years_and_over!!65_years_and_over!!Percent_below_poverty_level": "Percent_Below_Poverty_Level_65+",
    "Total!!White_alone": "White_alone", "Total!!Asian_alone": "Asian_alone", "Total!!Black_or_African_American_alone": "Black_or_African_American_alone",
    "Total!!American_Indian_and_Alaska_Native_alone": "American_Indian_and_Alaska_Native_alone", "Total!!Native_Hawaiian_and_Other_Pacific_Islander_alone": "Native_Hawaiian_and_Other_Pacific_Islander_alone",
    "Total!!Some_other_race_alone": "Some_other_race_alone", "Total!!Two_or_more_races": "Two_or_more_races", "Total!!Urban":"Urban", "Total!!Rural":"Rural"}, axis=1)

rest = ['Total_Pop','Male_Percent', 'Female_Percent','Pop_25+', 'Percent_HSGrad_Pop_25+', 'Pop_16+','Percent_Labor_Force_Pop_16+', 'Percent_Civillian_Labor_Force_Pop_16+','Percent_Employed', 'Percent_Unemployed', 'Workers_16+',\
    'Mean_Travel_Time', 'Agriculture_Percent', 'Construction_Percent','Manufacturing_Percent', 'Households', 'Median_household_income','Mean_earnings', 'Percent_Below_Poverty_Level','Percent_Below_Poverty_Level_18+', 
    'Percent_Below_Poverty_Level_65+','White_alone', 'Asian_alone', 'Black_or_African_American_alone','American_Indian_and_Alaska_Native_alone','Native_Hawaiian_and_Other_Pacific_Islander_alone','Some_other_race_alone', 'Two_or_more_races', 'Urban', 'Rural']

df2[rest] = df2[rest].apply(pd.to_numeric, errors='coerce')

df2[['Pop_25+', 'Pop_16+', 'Households', 'White_alone', 'Asian_alone', 'Black_or_African_American_alone', 'American_Indian_and_Alaska_Native_alone', 'Native_Hawaiian_and_Other_Pacific_Islander_alone', 'Some_other_race_alone','Two_or_more_races' ,'Urban', 'Rural']] = \
    (df2[['Pop_25+', 'Pop_16+', 'Households', 'White_alone', 'Asian_alone', 'Black_or_African_American_alone', 'American_Indian_and_Alaska_Native_alone', 'Native_Hawaiian_and_Other_Pacific_Islander_alone', 'Some_other_race_alone','Two_or_more_races' ,'Urban', 'Rural']].div(df2['Total_Pop'], axis = 0)) * 100

df2['Workers_16+'] = (df2['Workers_16+'] / df2['Labor_Force_Pop_16+']) * 100
df2.drop('Labor_Force_Pop_16+', axis = 1, inplace = True) # then we can drop this


tmpdf = diox.loc[:,['geoid', 'city', 'county']]
tmpdf = tmpdf.drop_duplicates(subset = 'geoid')
tmpdf['geoidred'] = tmpdf['geoid'].str[:9]
tmpdf2 = df2.loc[:, ['Census_Tract','id']]
tmpdf2['idred'] = tmpdf2['id'].str[:9]
tmpdf3 = pd.merge(left = tmpdf, right = tmpdf2, left_on='geoidred', right_on='idred', how='inner')
df2['dioxin_exposure'] = df2['id'].isin(tmpdf3['id'])
df2["dioxin_exposure"] = df2["dioxin_exposure"].astype(int)
df_final = df2.merge(nybl2, left_on='id', right_on='geoid', how='left')

df_final.to_csv("/Users/7i3/Documents/Python/allUS.csv")